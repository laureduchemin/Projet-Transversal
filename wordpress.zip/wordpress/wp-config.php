<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier contient les réglages de configuration suivants : réglages MySQL,
 * préfixe de table, clefs secrètes, langue utilisée, et ABSPATH.
 * Vous pouvez en savoir plus à leur sujet en allant sur
 * {@link http://codex.wordpress.org/fr:Modifier_wp-config.php Modifier
 * wp-config.php}. C'est votre hébergeur qui doit vous donner vos
 * codes MySQL.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d'installation. Vous n'avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en "wp-config.php" et remplir les
 * valeurs.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define('DB_NAME', 'PROJET');

/** Utilisateur de la base de données MySQL. */
define('DB_USER', 'root');

/** Mot de passe de la base de données MySQL. */
define('DB_PASSWORD', 'root');

/** Adresse de l'hébergement MySQL. */
define('DB_HOST', 'localhost');

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define('DB_CHARSET', 'utf8mb4');

/** Type de collation de la base de données.
  * N'y touchez que si vous savez ce que vous faites.
  */
define('DB_COLLATE', '');

/**#@+
 * Clefs uniques d'authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clefs secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n'importe quel moment, afin d'invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'WF8D!VFv,=RdB)73lZSCTy8KM[FDXjTckceE/WuSz6L1LQ#ZgNChY.)>N=5BqNQ?');
define('SECURE_AUTH_KEY',  '0)[;^+L`l5h`yCo}4K6y 9!bgYlOfuS=E/2ey=E-k{zlSu BGh(pBQ8*dY*uJG]V');
define('LOGGED_IN_KEY',    'K+-/!ekGEficJ7=Lz[ioR>>X?$}9vCP%0C+Sd7t@ WTO?0%bj{yDXfF7G]ryEPO?');
define('NONCE_KEY',        'ir?lLPJ|qf&Zs) v*{=dk]y}=+zom[z|bCXrJlJi/Qxgc%G<g9FaUa=}r$K15!r<');
define('AUTH_SALT',        '1L,+Z<d-/sabuQS{lb-*K{nV|h+M$,!6-DCfcp.%V6^u|5$-OMqZ4Z|fszmGfI}k');
define('SECURE_AUTH_SALT', '-,j@g:.M70<W{`R,!N[|):u,$c~I;:Jpd:Zi=>~S2JHQ [$-kEU=;|.=G=|#*DuQ');
define('LOGGED_IN_SALT',   'tRpOr-z)Gh>g]`5C P9;&-Iq.lXc+]J`h6},9S(%L-Y3 >g7_|$w&Bf2oZmowrx=');
define('NONCE_SALT',       '|}.~JD+h|Gz-^E>+kLS[Z2/;yl|Bk!U|oZ&[7;[CBw,Y-KDrFfbwu+6QhIeo8c?K');
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N'utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés!
 */
$table_prefix  = 'wp_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l'affichage des
 * notifications d'erreurs pendant vos essais.
 * Il est fortemment recommandé que les développeurs d'extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 */
define('WP_DEBUG', false);

/* C'est tout, ne touchez pas à ce qui suit ! Bon blogging ! */

/** Chemin absolu vers le dossier de WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once(ABSPATH . 'wp-settings.php');